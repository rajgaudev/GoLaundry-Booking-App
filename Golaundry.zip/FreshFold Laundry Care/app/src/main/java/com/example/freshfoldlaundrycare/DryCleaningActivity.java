package com.example.freshfoldlaundrycare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DryCleaningActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dry_cleaning);
    }
}