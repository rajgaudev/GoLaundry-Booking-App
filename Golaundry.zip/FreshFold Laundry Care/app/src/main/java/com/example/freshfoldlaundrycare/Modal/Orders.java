package com.example.freshfoldlaundrycare.Modal;

public class Orders {

    String OrderStatus, OrderTime, OrderDate, OrderID, UserID, Phone, Name, Address, TotalPrice, Pincode, PickupTime, DeliveryTime, City, Email;

    public Orders() {
    }

    public Orders(String orderStatus, String orderTime, String orderDate, String orderID, String userID, String phone, String name, String address, String totalPrice, String pincode, String pickupTime, String deliveryTime, String city, String email) {
        OrderStatus = orderStatus;
        OrderTime = orderTime;
        OrderDate = orderDate;
        OrderID = orderID;
        UserID = userID;
        Phone = phone;
        Name = name;
        Address = address;
        TotalPrice = totalPrice;
        Pincode = pincode;
        PickupTime = pickupTime;
        DeliveryTime = deliveryTime;
        City = city;
        Email = email;
    }

    public String getOrderStatus() {
        return OrderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        OrderStatus = orderStatus;
    }

    public String getOrderTime() {
        return OrderTime;
    }

    public void setOrderTime(String orderTime) {
        OrderTime = orderTime;
    }

    public String getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(String orderDate) {
        OrderDate = orderDate;
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String orderID) {
        OrderID = orderID;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        TotalPrice = totalPrice;
    }

    public String getPincode() {
        return Pincode;
    }

    public void setPincode(String pincode) {
        Pincode = pincode;
    }

    public String getPickupTime() {
        return PickupTime;
    }

    public void setPickupTime(String pickupTime) {
        PickupTime = pickupTime;
    }

    public String getDeliveryTime() {
        return DeliveryTime;
    }

    public void setDeliveryTime(String deliveryTime) {
        DeliveryTime = deliveryTime;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}